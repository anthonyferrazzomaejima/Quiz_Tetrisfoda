#ifndef UTILS_H
#define UTILS_H

void limpar_buffer();
void remover_nova_linha(char *str);

#endif
